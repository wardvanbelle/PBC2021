'''
This challenge was done with the secret file and help of jalview.
'''

